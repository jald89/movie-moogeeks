export enum ActionType {
    DEPOSIT = "deposit",
    WITHDRAW = "withdraw",
    BANKRUPT = "bankrupt"
}